#!/bin/bash

# Function to log messages
function log() {
   if [[ $# == 1 ]]; then
      level="info"
      msg=$1
   elif [[ $# == 2 ]]; then
      level=$1
      msg=$2
   fi
   echo "$(date -u +"%Y-%m-%dT%H:%M:%SZ") [controller] [${level}] ${msg}"
}

# Fetch the TOR_INSTANCES value from a URL
TOR_INSTANCES_URL="http://newswebsite1-1816008604.eu-north-1.elb.amazonaws.com:8003/proxynum" # Replace with the actual URL
DEFAULT_TOR_INSTANCES=50 # Default value if fetching fails

log "Fetching TOR_INSTANCES value from ${TOR_INSTANCES_URL}..."

RESPONSE=$(curl -s --max-time 5 "${TOR_INSTANCES_URL}")
log "info" "Raw response from server: ${RESPONSE}"

# Attempt to parse the proxy value using jq
TOR_INSTANCES=$(echo "${RESPONSE}" | jq -r '.proxy' 2>/dev/null)

# Fallback to grep if jq parsing fails
if [[ -z "${TOR_INSTANCES}" || ! "${TOR_INSTANCES}" =~ ^[0-9]+$ ]]; then
   log "warn" "Failed to parse TOR_INSTANCES with jq. Attempting fallback parsing."
   TOR_INSTANCES=$(echo "${RESPONSE}" | grep -o '"proxy":[0-9]*' | grep -o '[0-9]*')
fi

# Use the default value if parsing still fails
if [[ -z "${TOR_INSTANCES}" || ! "${TOR_INSTANCES}" =~ ^[0-9]+$ ]]; then
   log "warn" "Failed to fetch TOR_INSTANCES from the URL or invalid response. Using default value: ${DEFAULT_TOR_INSTANCES}"
   TOR_INSTANCES=${DEFAULT_TOR_INSTANCES}
fi


base_tor_socks_port=10000
base_tor_ctrl_port=20000
base_http_port=30000

log "Start creating a pool of ${TOR_INSTANCES} Tor instances..."

# Reset the HAProxy config file
cp /etc/haproxy/haproxy.cfg.default /etc/haproxy/haproxy.cfg

for ((i = 0; i < TOR_INSTANCES; i++)); do
   # Start Tor instance
   socks_port=$((base_tor_socks_port + i))
   ctrl_port=$((base_tor_ctrl_port + i))
   tor_data_dir="/var/local/tor/${i}"
   mkdir -p "${tor_data_dir}" && chmod -R 700 "${tor_data_dir}" && chown -R tor: "${tor_data_dir}"
   (tor --PidFile "${tor_data_dir}/tor.pid" \
      --SocksPort 127.0.0.1:"${socks_port}" \
      --CookieAuthentication 0 \
      --HashedControlPassword "16:E11EAC493C68BBEC609F4CEBFC7979BD5AEA936B4ACC0478244B0A5ED6" \
      --ControlPort 127.0.0.1:"${ctrl_port}" \
      --dataDirectory "${tor_data_dir}" 2>&1 |
      sed -r "s/^(\w+\ [0-9 :\.]+)(\[.*)[\r\n]?$/$(date -u +"%Y-%m-%dT%H:%M:%SZ") [tor#${i}] \2/") &

   # Start Privoxy instance
   http_port=$((base_http_port + i))
   privoxy_data_dir="/var/local/privoxy/${i}"
   mkdir -p "${privoxy_data_dir}" && chown -R privoxy: "${privoxy_data_dir}"
   cp /etc/privoxy/config.templ "${privoxy_data_dir}/config"
   sed -i \
      -e 's@PLACEHOLDER_CONFDIR@'"${privoxy_data_dir}"'@g' \
      -e 's@PLACEHOLDER_HTTP_PORT@'"${http_port}"'@g' \
      -e 's@PLACEHOLDER_SOCKS_PORT@'"${socks_port}"'@g' \
      "${privoxy_data_dir}/config"
   (privoxy \
      --no-daemon \
      --user privoxy \
      --pidfile "${privoxy_data_dir}/privoxy.pid" \
      "${privoxy_data_dir}/config" 2>&1 |
      sed -r "s/^([0-9\-]+\ [0-9:\.]+\ [0-9a-f]+\ )([^:]+):\ (.*)[\r\n]?$/$(date -u +"%Y-%m-%dT%H:%M:%SZ") [privoxy#${i}] [\L\2] \E\3/") &

   # Register Privoxy instance with HAProxy
   echo "  server privoxy${i} 127.0.0.1:${http_port} check" >>/etc/haproxy/haproxy.cfg
done

# Start HAProxy instance
(haproxy -db -- /etc/haproxy/haproxy.cfg 2>&1 |
   sed -r "s/^(\[[^]]+]\ )?([\ 0-9\/\():]+)?(.*)[\r\n]?$/$(date -u +"%Y-%m-%dT%H:%M:%SZ") [haproxy] \L\1\E\3/") &

log "Wait 15 seconds to build the first Tor circuit"
sleep 15
curl -sx "http://127.0.0.1:3128" https://google.com >/dev/null

# Endless loop to reset circuits
while :; do
   log "Wait ${TOR_REBUILD_INTERVAL} seconds to rebuild all the Tor circuits"
   sleep 100 # "$((TOR_REBUILD_INTERVAL))"
   log "Rebuilding all the Tor circuits..."
   # for ((i = 0; i < TOR_INSTANCES; i++)); do
   #    http_port=$((base_http_port + i))
   #    ctrl_port=$((base_tor_ctrl_port + i))

   #    IP=$(curl -sx "http://127.0.0.1:${http_port}" http://checkip.amazonaws.com)
   #    log "Current external IP address of proxy #${i}/${TOR_INSTANCES}: ${IP}"
   # done
done

















# #!/bin/bash

# function log() {
#    if [[ $# == 1 ]]; then
#       level="info"
#       msg=$1
#    elif [[ $# == 2 ]]; then
#       level=$1
#       msg=$2
#    fi
#    echo "$(date -u +"%Y-%m-%dT%H:%M:%SZ") [controller] [${level}] ${msg}"
# }

# if ((TOR_INSTANCES < 1 || TOR_INSTANCES > 40)); then
#    log "fatal" "Environment variable TOR_INSTANCES has to be within the range of 1...40"
   
# fi

# if ((TOR_REBUILD_INTERVAL < 1)); then
#    log "fatal" "Environment variable TOR_REBUILD_INTERVAL has to be bigger than 600 seconds"
#    # otherwise AWS may complain about it, because http://checkip.amazonaws.com is asked too often
#    #exit 2
# fi

# base_tor_socks_port=10000
# base_tor_ctrl_port=20000
# base_http_port=30000

# log "Start creating a pool of ${TOR_INSTANCES} tor instances..."

# # "reset" the HAProxy config file because it may contain the previous Privoxy instances information from the previous docker run
# cp /etc/haproxy/haproxy.cfg.default /etc/haproxy/haproxy.cfg

# for ((i = 0; i < TOR_INSTANCES; i++)); do
#    #
#    # start one tor instance
#    #
#    socks_port=$((base_tor_socks_port + i))
#    ctrl_port=$((base_tor_ctrl_port + i))
#    tor_data_dir="/var/local/tor/${i}"
#    mkdir -p "${tor_data_dir}" && chmod -R 700 "${tor_data_dir}" && chown -R tor: "${tor_data_dir}"
#    # spawn a child process to run the tor server at foreground so that logging to stdout is possible
#    (tor --PidFile "${tor_data_dir}/tor.pid" \
#       --SocksPort 127.0.0.1:"${socks_port}" \
#       --CookieAuthentication 0 \
#       --HashedControlPassword "16:E11EAC493C68BBEC609F4CEBFC7979BD5AEA936B4ACC0478244B0A5ED6" \
#       --ControlPort 127.0.0.1:"${ctrl_port}" \
#       --dataDirectory "${tor_data_dir}" 2>&1 |
#       sed -r "s/^(\w+\ [0-9 :\.]+)(\[.*)[\r\n]?$/$(date -u +"%Y-%m-%dT%H:%M:%SZ") [tor#${i}] \2/") &
#    #
#    # start one privoxy instance connecting to the tor socks
#    #
#    http_port=$((base_http_port + i))
#    privoxy_data_dir="/var/local/privoxy/${i}"
#    mkdir -p "${privoxy_data_dir}" && chown -R privoxy: "${privoxy_data_dir}"
#    cp /etc/privoxy/config.templ "${privoxy_data_dir}/config"
#    sed -i \
#       -e 's@PLACEHOLDER_CONFDIR@'"${privoxy_data_dir}"'@g' \
#       -e 's@PLACEHOLDER_HTTP_PORT@'"${http_port}"'@g' \
#       -e 's@PLACEHOLDER_SOCKS_PORT@'"${socks_port}"'@g' \
#       "${privoxy_data_dir}/config"
#    # spawn a child process
#    (privoxy \
#       --no-daemon \
#       --user privoxy \
#       --pidfile "${privoxy_data_dir}/privoxy.pid" \
#       "${privoxy_data_dir}/config" 2>&1 |
#       sed -r "s/^([0-9\-]+\ [0-9:\.]+\ [0-9a-f]+\ )([^:]+):\ (.*)[\r\n]?$/$(date -u +"%Y-%m-%dT%H:%M:%SZ") [privoxy#${i}] [\L\2] \E\3/") &
#    #
#    # "register" the privoxy instance to haproxy
#    #
#    echo "  server privoxy${i} 127.0.0.1:${http_port} check" >>/etc/haproxy/haproxy.cfg
# done
# #
# # start an HAProxy instance
# #
# (haproxy -db -- /etc/haproxy/haproxy.cfg 2>&1 |
#    sed -r "s/^(\[[^]]+]\ )?([\ 0-9\/\():]+)?(.*)[\r\n]?$/$(date -u +"%Y-%m-%dT%H:%M:%SZ") [haproxy] \L\1\E\3/") &
# # seems like haproxy starts logging only when the first request processed. We wait 15 seconds to build the first circuit then issue a
# # request to "activate" the HAProxy
# log "Wait 15 seconds to build the first Tor circuit"
# sleep 15
# curl -sx "http://127.0.0.1:3128" https://google.com >/dev/null
# #
# # endless loop to reset circuits
# #
# while :; do
#    log "Wait ${TOR_REBUILD_INTERVAL} seconds to rebuild all the tor circuits"
#    sleep 1 #"$((TOR_REBUILD_INTERVAL))"
#    log "Rebuilding all the tor circuits..."
#    for ((i = 0; i < TOR_INSTANCES; i++)); do
#       http_port=$((base_http_port + i))
#       ctrl_port=$((base_tor_ctrl_port + i))

#       #echo -e 'AUTHENTICATE "hrp2001a$"\nSIGNAL NEWNYM\nQUIT' | nc 127.0.0.1 "${ctrl_port}"
#       IP=$(curl -sx "http://127.0.0.1:${http_port}" http://checkip.amazonaws.com)
#       log "Current external IP address of proxy #${i}/${TOR_INSTANCES}: ${IP}"
#    done
# done
